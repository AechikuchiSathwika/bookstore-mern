const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true, min: 0 },
  type: { type: String, required: true },
  author: { type: String, required: true },
  image: { type: String, required: true },
});

module.exports = mongoose.model("Book", bookSchema);
